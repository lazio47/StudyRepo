package aula07.Exercicio7_1;

public abstract class Forma {
    public abstract double Perimetro();
    public abstract double Area();
}
