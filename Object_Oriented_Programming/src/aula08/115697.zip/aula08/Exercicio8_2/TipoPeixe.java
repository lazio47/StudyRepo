package aula08.Exercicio8_2;

public class TipoPeixe {
    public static String CONGELADO = "Congelado";
    public static String FRESCO = "Fresco";
}
