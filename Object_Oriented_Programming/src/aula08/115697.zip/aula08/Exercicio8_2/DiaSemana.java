package aula08.Exercicio8_2;

public enum DiaSemana {
    Domingo, Segunda,Terça, Quarta, Quinta, Sexta, Sábado;
}
