package aula08.Exercicio8_2;

public class VariedadeCarne {
    public static String FRANGO = "Frango";
    public static String VACA = "Vaca";
    public static String PERU = "Peru";
    public static String PORCO = "Porco";
    public static String OUTRO = "Outro";

}
