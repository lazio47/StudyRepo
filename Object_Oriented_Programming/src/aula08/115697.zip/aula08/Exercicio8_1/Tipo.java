package aula08.Exercicio8_1;

public enum Tipo {
    desportivo, estrada;
}
