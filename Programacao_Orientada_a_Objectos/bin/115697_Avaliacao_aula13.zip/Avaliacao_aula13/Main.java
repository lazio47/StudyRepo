package Avaliacao_aula13;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ContactManager manager = new ContactManager();
        manager.load("contactos.txt");
        Scanner sc = new Scanner(System.in);
        int escolha;
        do{
            System.out.println("1.adicionar contacto ");
            System.out.println("2.modificar contacto ");
            System.out.println("3.apagar contacto ");
            System.out.println("4.procurar contacto por nome ");
            System.out.println("5.procurar contacto por telemovel ");
            System.out.println("6.procurar contacto por e-mail ");
            System.out.println("7.Listar contactos ");
            System.out.println("8.Listar contactos ordenados por nome ");
            System.out.println("9.Listar contactos ordenados por telemovel ");
            System.out.println("10.Listar contactos ordenados por e-mail ");
            System.out.println("11.Listar contactos ordenados por data de nascimento ");
            System.out.println("12.fechar");
            escolha = sc.nextInt();
            switch(escolha){
                case 1:
                    manager.addContact(null);
                    break;
                case 2:
                    break;
                case 3:
                    manager.removeContact(null);
                    break;
                case 4:
                    System.out.println("Insira o nome ");
                    String nome = sc.nextLine();
                    System.out.println(manager.searchContactByname(nome).toString());
                    break;
                case 5:
                    System.out.println("Insira o telemovel ");
                    int tel = sc.nextInt();
                    sc.next();
                    System.out.println(manager.searchContactByPhoneNumber(tel).toString());
                    break;
                case 6:
                    System.out.println("Insira o email ");
                    String mail = sc.nextLine();
                    System.out.println(manager.searchContactByEmail(mail).toString());
                    break;
                case 7:
                    manager.listAllContacts();
                    break;
                case 8: 
                    manager.listContactsByName();
                    break;
                case 9:
                    manager.listContactsByPhoneNumber();
                    break;
                case 10:
                    manager.listContactsByEmail();
                    break;
                case 11:
                    manager.listContactsByBirthDate();
                case 12:
                    System.out.println("A encerrar!");

            }
        }while(escolha!=12);
        sc.close();
    }
}
